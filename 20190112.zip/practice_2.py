# problem 1
a = 20180108
a = str(a)

y = a[:4]
m = a[4:6]
d = a[6:]

print("{}년 {}월 {}일".format(y, m, d))

# problem 2
b = "hi Sangmook"
print("hello" + b[2:])

# problem 3
print(b.replace("hi", "hello"))


"ABCDEFG"
# problem 4
user_str = input("Please insert your string: ")
print(user_str[0].upper() + user_str[1:-1].lower() + user_str[-1].upper())

