# problem 1
a = 20180110

y =
m =
d =

print("{:04d}년 {:02d}월 {:02d}일".format(y, m, d))


# problem 2

word = input("input your word:")
"""
apple   -> a____
banana  -> b_____
"""







