"""
자료형 (1)
"""
print("{:-^20}".format("변수"))
a = 10
A = 100
a = 200
print(a)


print("{:-^20}".format("숫자형 자료형"))
b = 1e2
print(b)
print("-" * 20)
print(6 % 5)
print(2 ** 4)

print("{:-^20}".format("문자열 자료형"))
a = "python is good"

b = """
안녕하세요~
저는 김상묵입니다.
스카이캐슬 재밌어요.
"""
print(b)
print("-" * 20)
print('I\'m a good boy')
print("he says \"python is good\"")
print("""He says "python is good" """)

print("-" * 20)
print("python \nis good")

# 문자열 연산자
print("-" * 20)
print("ABC" + "DEF")
print("abc" * 3)

# 문자열 인덱싱
print("-" * 20)
print("ABCDEFG"[0])
a = "ABCDEFG"
print(a[2])
print(a[-1])

# 문자열 슬라이싱
print("-" * 20)
b = "abcdefg"
print(b[0:2])
print(b[4:-1])
print(b[4:])

# 문자열 포매팅(1)
print("-" * 20)
name_format = "나의 이름은 %s입니다."
print(name_format % "김상묵")
d = name_format % "김상묵"
print(d)
print("-" * 20)
print("나의 나이는 %d입니다." % 20)
name_age_format = "나의 이름 %s이고 나이는 %d입니다."
print(name_age_format % ("김상묵", 20))

print("-" * 20)
print(str(1234) + "5678")

name_age_format = "나의 이름 %s이고 나이는 %s입니다."
age = 20
print(name_age_format % ("김상묵", str(age)))

# 문자열 관련 함수
# count
print("-" * 20)
a = "ABCABCABABCCC"
print(a.count("A"))
print("ABCABCABABCCC".count("A"))
print(a.count("ABC"))

# find & index
print("-" * 20)
a = "ABCDEFG"
print(a.find("D"))
print(a.index("D"))

# print(a.index("H"))
print(a.find("H"))

# join
print("-" * 20)
a = "abcd"
print("-".join(a))

# upper & lower
print("-" * 20)
b = "AbcdEfdde"
print(b.upper())
print(b.lower())

# lstrip & rstrip & strip
print("-" * 20)
a = "         abc         "
print(a.lstrip())
print(a.rstrip())
print(a.strip())

# replace
print("-" * 20)
print("hello hello sangmook".replace("hello", "hi"))

# split
print("-" * 20)
a = "abc def ghi"
print(a.split())
print(a.split('e'))

# format
print("-" * 20)
name_format = "나의 이름은 {} 입니다."
name_age_format = "나의 이름은 {0}이고 나이는 {1}살입니다."
print(name_format.format("김상묵"))
print(name_age_format.format("김상묵", 30))

name_age_format = "나의 이름은 {name}이고 나이는 {age}살입니다."
print(name_age_format.format(name="김상묵", age=30))


print("{:<10} Sangmook".format("hi"))
print("{:^10} Sangmook".format("hi"))
print("{:>10} Sangmook".format("hi"))















