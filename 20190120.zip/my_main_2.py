from root_package.sub_package_1.module1 import *

print_module1()

from root_package.sub_package_2 import *
module3.print_module3()
