class A:
    def __init__(self, x, y):
        self.x = x
        self.y = y


def add(x, y):
    return x + y

a = 10

print("my statistics __name__:", __name__)

if __name__ == "__main__":
    print(add(10, 20))
    print(add(30, 20))
    print(add(80, 30))



