import random

lotto_lst = []

while len(lotto_lst) < 6:
    num = random.randint(1, 45)

    if num in lotto_lst:
        continue

    lotto_lst.append(num)

print(lotto_lst)