def print_module4():
    print("module4")