def print_module3():
    print("module3")