def print_module1():
    print("module1")