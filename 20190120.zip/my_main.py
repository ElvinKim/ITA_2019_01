# import my_statistics
#
# print(my_statistics.a)
# print(my_statistics.add(10, 20))
#
# b = my_statistics.A(10, 20)
#
# print(b.x)

# from my_statistics import add, a, A
print("my main __name__:", __name__)
from my_statistics import *

print(add(10, 20))



