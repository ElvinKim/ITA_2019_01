class Knight:
    def __init__(self, n, level, hp):
        self.name = n  # 굳이 변수명을 맞출 필요는 없다.
        self.level = level
        self.hp = hp

    def move(self, direction):
        print(direction + "으로(로) 이동합니다.")

    def attack(self):
        print("self id", id(self))
        print(self.name + "이(가) 공격합니다.")

    def get_level(self):
        return self.level

    def set_level(self, level):
        if level > 999:
            level = 999
        self.level = level

    def get_hp(self):
        return self.hp

    def set_hp(self, hp):
        self.hp = hp

k1 = Knight("만년동 핵폭탄", 20, 200)

print(k1.name)
print(k1.level)
k1.level = 21
print(k1.level)
print("-" * 20)
print(k1.get_level())
k1.set_level(22)
print(k1.get_level())
k1.set_level(100000)
print(k1.get_level())
print("-" * 20)


class Character:
    def __init__(self, n, level, hp):
        self.name = n  # 굳이 변수명을 맞출 필요는 없다.
        self.level = level
        self.hp = hp

    def move(self, direction):
        print(direction + "으로(로) 이동합니다.")

    def attack(self):
        print("self id", id(self))
        print(self.name + "이(가) 공격합니다.")

    def get_level(self):
        return self.level

    def set_level(self, level):
        if level > 999:
            level = 999
        self.level = level

    def get_hp(self):
        return self.hp

    def set_hp(self, hp):
        self.hp = hp


class Wizard(Character):

    def magic(self):
        print(self.name + "이(가) 마법을 사용합니다.")

w1 = Wizard('만년동 이은결', 30, 100)

print(w1.get_level())
print(w1.get_hp())


# Practice 1
print("-" * 20)
class Vector2D:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def getx(self):
        return self.x

    def setx(self, x):
        self.x = x

    def gety(self):
        return self.y

    def sety(self, y):
        self.y = y

    def get(self):
        return (self.x, self.y)

    def __str__(self):
        return "<{}, {}>".format(self.x, self.y)

    def __eq__(self, other):
        return self.get() == other.get()


v1 = Vector2D(1, 2)
v2 = Vector2D(1, 2)

print(v1)  # <1, 2>
print(v1 == v2)



