#
# while True:
#     try:
#         a = int(input("input a :"))
#         b = int(input("input b :"))
#         print("{} / {} = {}".format(a, b, a / b))
#     except ValueError as e:
#         print(e)
#         print("문자는 숫자로 못바꿔!!")
#     except ZeroDivisionError as e:
#         print(e)
#         print("0으로 나누지 마!!!")


while True:
    try:
        a = int(input("input a :"))
        b = int(input("input b :"))
        print("{} / {} = {}".format(a, b, a / b))
    except Exception as e:
        print(e)
