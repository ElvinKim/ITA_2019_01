sample_news = '''
Hong Kong (CNN)Since the beginning of January, the Chinese military has revealed a dizzying array of sophisticated and powerful new weaponry.

The testing of some of these devices has been accompanied by great fanfare. But just how plausible is the new technology in a battlefield situation?
With Tuesday's report from the US Defense Intelligence Agency that China "leads the world" in some weapons systems, a closer look at Beijing's latest claims is in order.
The mother of all bombs

State-run Global Times reported in early January that China had tested its version of the "mother of all bombs," a named adopted from the US Air Force's Massive Ordnance Air Blast bomb, or MOAB, which it dropped on an Afghan cave complex in 2017.
China's version of the weapon is second only in power to a nuclear bomb, according to the Global Times report. Pictures accompanying the story showed the weapon falling from the bomb bay of what was said to be an H-6K jet bomber and then a huge, fiery blast on the ground.
"The massive blast can easily and completely wipe out fortified ground targets such as reinforced buildings, bastions and defense shelters," Global Times quoted military analyst Wei Dongxu as saying.
The report says the Chinese MOAB is smaller and lighter than its American counterpart, which enabled it to be dropped from the bomber much like a conventional weapon, unlike the US version which is essentially shoved out the back of a C-130 cargo plane. As a result, China claims its version of a massive, non-nuclear explosive will be more accurate than its US counterpart.
Verdict: Plausible. China has been trying to copy military technology from others and refine it to its needs. But even with what it says is its superior delivery method, the bomb's deployment in battle would likely require full air superiority.
The 'Underground Steel Great Wall'

A story posted on the PLA's English-language website on January 13 proclaims the Underground Steel Great Wall (USGW) to be a set of defensive installations set deep under mountainous terrain at an undisclosed location somewhere in China.
The wall is intended to protect secure military bases from enemy attack. According to the report, the rock of the mountains would withstand much of a potential blast. The "steel" part of the wall, meanwhile, is a reference to the work of Qian Qihu, a scientist who is said to have figured out how to provide extra blast protection to vulnerable exits and entrances.
Qian says his work will provide protection from future hypersonic weapons, missiles that can fly five to 10 times the speed of sound, and can change direction in flight to avoid missile defenses while delivering nuclear warheads.
"Qian's work guaranteed the safety of the country's strategic weapons, launch and storage facilities as well as commanders' safety during extreme times," military expert Song Zhongping says in the story.
Verdict: Skeptical. Though Russia claims to have a hypersonic missile ready for deployment, one has never been used in combat so developing "steel" that can withstand such a weapon would seem theoretical at best.
Ship-killer ballistic missiles
File photo taken on September 3, 2015, shows Chinese military vehicles carrying DF-26 ballistic missiles participating in a military parade at Tiananmen Square in Beijing.
File photo taken on September 3, 2015, shows Chinese military vehicles carrying DF-26 ballistic missiles participating in a military parade at Tiananmen Square in Beijing.
After the US Navy sent a guided-missile destroyer near Chinese-claimed islands in the South China Sea on January 10, Chinese state media said the People's Liberation Army had deployed DF-26 ballistic missiles "capable of targeting medium and large ships" at sea.
A Global Times report said the deployment of the missiles with a range of 3,400 miles (5,471 kilometers) "is a good reminder that China is capable of safeguarding its territory."
The DF-26, unveiled during a military parade in 2015 in Beijing, was originally seen as an intermediate range ballistic missile for use against land targets. Analysts dubbed it the "Guam killer" owing to the fact it brought the US Pacific island and its important military bases within China's missile reach.
But China has never offered proof that it has tested the DF-26 in the anti-ship configuration, able to target warships on the move.
Verdict: Skeptical. Military analyst Carl Schuster, a former US Navy captain, says no military has ever successfully developed an anti-ship ballistic missile. And actually using one in combat would require multiple practice launches to refine tactics and procedures, something that China has shown no evidence of having done.
Two-seat steatlh fighter-bomber
Play Video

China shows off new J-20 stealth fighter (2016) 00:48
A new version of the J-20 stealth fighter, introduced into the PLA Air Force fleet in February 2018, could be configured into fighter-bombers as well as electronic warfare and aircraft carrier-based versions, according to a report on the PLA's English-language website.
Those versions of the twin-engine jet might also include a seat for a second pilot, said the report, picked up from Global Times.
"All current stealth fighter jets feature single-seat, so the potential J-20 variant might become the first two-seat stealth fighter jet in the world," the report said, citing China Central Television.
The report said a second crew would be needed to handle the flood of information coming into the J-20's digital battlefield systems.
Verdict: Likely. The US DIA's China report said "the PLAAF is developing new medium- and long-range stealth bombers to strike regional and global targets. Stealth technology continues to play a key role in the development of these new bombers." These new bombers could be operational within six years, the DIA said.
Super soldiers with futuristic weapons
Play Video

The bullet that can change direction mid-air 01:26
Hand-held knives that fire bullets, pistols that shoot around corners and assault rifles that launch grenades. Those are just some of the things China wants to equip its special forces with to create "super soldiers," according to a story on the PLA website.
The bullet knives could be used when enemies are close, and the corner pistols would allow soldiers to hide behind walls while engaging foes coming at them from a right angle, according to the report.
The rifle-grenade launcher combo provides "the strongest individual firepower in the world," and connects the battlefield using digital sensors, a positioning system and data sharing, the report says.
Military analyst Wei Dongxu calls the new arms "sci-fi" weapons that will make one Chinese soldier the equal of 10 adversaries.
Verdict: Plausible. While the weapons may sound a bit like something Q developed for James Bond, China isn't the first country to work on these kinds of things. In 2015, the US Defense Advanced Research Products Agency said it was developing .50-caliber bullets with optical sensors that could change direction in mid-air.
Shanghai-sized radio antenna
A nuclear-powered submarine of the People&#39;s Liberation Army Navy&#39;s North Sea Fleet prepares to dive into the sea. 
A nuclear-powered submarine of the People's Liberation Army Navy's North Sea Fleet prepares to dive into the sea.
A New Year's Eve report in the South China Morning Post said China has completed a massive Wireless Electromagnetic Method (WEM) radio antenna.
The WEM consists of high-voltage wires strung form steel towers arranged in a cross pattern 60 kilometers wide and 80 to 100 kilometers long, according to the SCMP report. As a rectangle on the map, that would cover and area of 3,700 square kilometers, just shy of the area of Shanghai, though China has not given the exact location of the antenna for security reasons.
Connected to power stations underground, the setup can send out extremely low frequency (ELF) radio signals that can travel through the Earth's crust for 3,500 kilometers, the report said.
Why would this be needed? It's how you get orders to submarines without them having to surface. And as analyst Joseph Trevithick writes on The War Zone blog, China has the world's largest submarine fleet.
Trevithick says ELF communication would allow China's nuclear-armed ballistic missile submarines to stay deeper in the ocean than other methods do. That would make them harder to detect and enhance their standing as a nuclear second-strike deterrent. The problem with the system is that it allows only one-way text communication, from base to sub.
Verdict: Likely. The technology is far from new so it's more of an infrastructure investment than any scientific breakthrough. The US Navy once based such systems in Michigan and Wisconsin, but shut them down early this century when better technologies were developed.
Naval rail gun
A screengrab from China state media CCTV purports to show railgun technology on a PLA Navy landing ship.
A screengrab from China state media CCTV purports to show railgun technology on a PLA Navy landing ship.
Reports in state-run media from early January said China would 'soon' be able to deploy electromagnetic railguns on its warships.
In theory, railguns will fire metal shells using an electrical rather than an explosive charge -- a potentially revolutionary development in weapons technology that would render gunpowder obsolete. With a range over 100 miles, the projectile would travel at up to nine times the speed of sound (6,850 mph). It would also use kinetic rather than explosive energy to destroy its target.
With no explosive residue, the electromagnetic railgun is expected to be more accurate and easier to maintain than conventional artillery.
Photos of what was said to be a railgun mounted on a PLA Navy landing ship circulated around the internet early this month.
A Global Times story quoted a Chinese naval expert, Li Jie, as saying the photos mean China's railgun may be in the final stages of testing. The weapon could be destined for use on China's brand-new Type 55 destroyers, among the most sophisticated on the planet, when operational, the report said.
Verdict: Plausible. The US Navy, too, has been working to perfect a railgun, and had the jump on China in development, said Schuster, the military analyst at Hawaii Pacific University. But China is catching up fast, he says, and may beat the US to actual deployment. Both could have working railguns at sea in less than a decade, he says.
'Flying saucer-like' stealth drone

Chinese television showed Beijing's new stealth Sky Hawk drone in flight for the first time in early January, boasting of the aircraft's ability to fly "faster, farther and avoid detection."
A report from state-sponsored Global Times called the drone "flying saucer-like." The aircraft, however, is in fact closer in appearance to the US Air Force's B-2 stealth bomber, albeit in miniature.
The Sky Hawk was on static display at Airshow China in Zhuhai in November, at which time the state-run Xinhua news service interviewed the aircraft's chief designer, Ma Hongzhong, who touted its features.
"It could very well be hidden from view, and it could have stronger capabilities of attack, defense and survival when it is used in combat," Ma said in a video interview.
He also said the craft represented an advance in aerodynamics that offer greater endurance, plus a larger interior that gives it the ability to carry more fuel and weapons.
Verdict: Plausible. The Sky Hawk is one of a series of drones in an expanding Chinese program for the unmanned aerial vehicles, with Chinese military use and export sales both being targeted. Despite the ballyhooing over the Sky Hawk flight, Song told Global Times that China still lags behind the US in stealth drone development. In 2013, the US Navy successfully launched and recovered a similar looking drone, the X-47B on an aircraft carrier. That aircraft in 2015 also successfully conducted an in-flight refueling.
Homegrown aircraft carrier
Play Video

China's second aircraft carrier sets sail 00:56
News reports say the PLA Navy's first homegrown aircraft carrier has completed its fourth round of sea trials and returned to the port where it was built, the Dalian Shipbuilding Industry Company (DSIC) shipyard in Dalian.
Before the carrier left for those trials, Global Times said the fourth round of tests was expected to focus on the ship's air wing, with tests being run on radar, air traffic control and launch and landing equipment on the 50,000-ton ship.
Wang Yunfei, a naval expert and retired PLA Navy officer, told Global Times it was possible J-15 fighter jets would try a takeoff-and-landing exercise during the fourth sea trial. Photos of the ship on its return to Dailan after 13 days at sea showed a J-15 and a helicopter on its deck, according to the South China Morning Post.
The latter report quoted military expert Li Jie as saying the carrier could be officially delivered to the PLA Navy by April 23, when it could participate in a large fleet review off Shandong province for Chinese Navy Day.
Verdict: Likely. With rumors in state-sponsored media that the new carrier will be in the Navy Day fleet review, it would be embarrassing to the PLA Navy if it didn't make it. Plus, China's first carrier, the Liaoning, and the new Type 55 destroyer, one of the largest and most sophisticated warships in Asia, are expected to be in the naval parade, according to Global Times. An image of all three sailing together would be a great, patriotic sight for domestic consumption.
'''

word_cnt_dict = {}

for word in sample_news.split():
    lower_word = word.lower()

    if word_cnt_dict.get(lower_word):
        word_cnt_dict[lower_word] += 1
    else:
        word_cnt_dict[lower_word] = 1

for word, cnt in word_cnt_dict.items():
    print(word, cnt)
















