print("{:=^20}".format("제어문"))
print("{:-^20}".format("if문"))
# if
if 1 < 2:
    print("test1")
    print("test2")

    if 1 > 2:
        print("test3")

# if-else
print("-" * 20)
num = 21
if num % 2 == 0:
    print("짝수")
else:
    print("홀수")

# if-elif-else
print("-" * 20)
num = 0

if num > 0:
    print("양수")
elif num < 0:
    print("음수")
else:
    print("zero")

# 조건 연산자
print("-" * 20)
print(1 > 2 or 2 < 3)
print(1 > 2 and 2 < 3)

x = 10

if not x > 30:
    print("test")

# in 조건문
print("-" * 20)
print("A" in ["A", "B", "C"])
print("python" in "python is very good")
print("the " in "there is a good boy")

# 자료형 참 과 거짓
print("-" * 20)
if 10:
    print("TEST")

if "test":
    print("TEST2")

if "":
    print("TEST3")

if None:
    print("TEST4")


print("{:-^20}".format("while문"))
x = 0
while x < 10:
    print(x)
    x += 1  # x = x + 1

# break
print("-" * 20)
y = 0
while True:
    if y > 10:
        break
    y += 2
print(y)

# while True:
# 	if 3 * x > 56:
# 		break
# 	x = x + 1
# print(x)
x = 0
while 3 * x < 56:
    x += 1
print(x)

# continue
print("-" * 20)
a = 0

while a <= 20:
    a += 1
    if a % 2 == 1:
        continue
    print(a)

# 무한 루프
# while True:
#     print("test")

print("{:-^20}".format("for문"))
for x in [1, 2, 3, 4]:
    print(x)
    print("-" * 10)

print("-" * 20)

for y in (1, 2, 3, 4):
    print(y * 2)

#  for loop with range
print("-" * 20)
for x in range(10):
    print(x)

for _ in range(5):
    print("TEST")

# 구구단
for i in range(2, 10):
    for j in range(1, 10):
        print("{} * {} = {}".format(i, j, i * j))
    print("-" * 10)

# list compression
print("-" * 20)
lst = []

for x in range(1, 11):
    lst.append(x ** 2)
print(lst)

lst_2 = [x ** 2 for x in range(1, 11)]
print(lst_2)

lst_3 = [str(x) for x in range(1, 11)]
print(lst_3)

# zip
print("-" * 20)
list1 = [1, 2, 3, 4, 5, 6, 7, 8]
list2 = ["a", "b", "c"]

for x, y in zip(list1, list2):
    print(x)


# enumerate
print("-" * 20)
c = ["python", "is", "very", "good"]
print(c)

for idx, x in enumerate(c):
    print(idx, x)
























