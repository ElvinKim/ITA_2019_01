s = input("input sentence:")
print(s)

scores = input("input your scores:")
