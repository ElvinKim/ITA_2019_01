lst = [1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 5, 6]
s = set(lst)
print(s)
l = list(s)
print(l)

l_2 = list(set(lst))
print(l_2)

t = tuple(l_2)
print(t)
print(list(t))





