"""
자료형 (2)
"""
print("{:=^20}".format("리스트"))

lst_1 = [1, 2, 3, 4, 5]
lst_2 = ["a", "b", "c"]
lst_3 = list("abcdefg")
print(lst_3)

# 인덱싱 & 슬라이싱
print("-" * 20)
a = ["Good", 1, 2, 3, ["a", "b"]]
print(a[0])
print(a[4])
print(a[4][1])

# 연산자
print("-" * 20)
print([1, 2, 3] + ["a", "b"])
print([1, 2, 3] * 3)

# 값 수정하기
print("-" * 20)
a = [1, 2, 3, 4, 5]
a[0] = 100
print(a)
print(a[0])
print(a[0:1])
a[1:4] = [200, 300, 400, 600, 700, 800]
print(a)

# a[1:2] = 2 error!

# 값 삭제하기
print("-" * 20)
print(a)
del a[0]
print(a)
a[1:4] = []
print(a)


print("{:-^20}".format("리스트 관련 함수"))
# append
a = [1, 2, 3, 4]
a.append(5)
print(a)

# sort
print("-" * 20)
b = [3, 1, 4, 5, 1, 2]
print(b.sort())
print(b)
# c = "hello sangmook"
# print(c.replace("hello", "hi"))
# print(c)

# reverse
print("-" * 20)
c = list("abcdefg")
print(c)
print(c.reverse())
print(c)

# index
print("-" * 20)
a = [2, 1, 4, 5, 6, 2, 3]
print(a.index(2))

# insert
print("-" * 20)
b = [1, 3, 4, 5, 6]
b.insert(1, 2)
print(b)

# remove
print("-" * 20)
a = [1, 2, 3, 1, 2, 3]
a.remove(1)
print(a)

# pop
print("-" * 20)
a = [1, 2, 3, 4, 5]
print(a.pop())
print(a)
print(a.pop(0))
print(a)
print(a.pop(1))

# count
print("-" * 20)
print([1, 2, 3, 1, 2, 3, 1, 2].count(1))

# extend
a = [1, 2, 3]
b = [4, 5, 6]
# a.extend(b) # a = a + b
# print(a)
a += b  # a = a + b
print(a)

print("{:=^20}".format("튜플"))
t = (1, 2, 3, 4, 5)
# t[0] = 10 error
x = 1
y = 2
z = 3
print(x, y, z)
x, y, z = (10, 20, 30)
print(x, y, z)
x, y, z = [100, 200, 300]
print(x, y, z)

print("{:=^20}".format("딕셔너리"))
me = {"name": "sangmook", "age": 30}
print(me["name"])
me["id"] = 100
print(me)
me['age'] = 20
print(me)
del me["age"]
print(me)

print("{:-^20}".format("딕셔너리 관련 함수"))
d = {"name": "sangmook", "age": 30, "id": 100}
print(d.keys())
print(d.values())
print(d.items())
# d.clear()
print(d)

# get
print("-" * 20)
print(d["age"])
print(d.get("age"))

# print(d["good"])
print(d.get("good"))
print(d.get("good", 0))


print("{:=^20}".format("boolean"))
print(1 > 2)
print(1 < 2)












