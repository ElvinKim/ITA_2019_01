print("*", end="")
