lst = []
lst.append(21)
lst += [42, 23, 14, 5, 66]
lst.sort()
print(lst)
print("max:", max(lst))
print("min:", min(lst))

# del lst[0]
# del lst[-1]
lst.remove(max(lst))
lst.remove(min(lst))





