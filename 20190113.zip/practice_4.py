num1 = int(input("input num1:"))
num2 = int(input("input num2:"))

if num1 > num2:
    print("num1 is bigger than num2")
elif num1 < num2:
    print("num2 is bigger than num1")
else:
    print("같다!!!!!")

