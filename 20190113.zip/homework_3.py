while True:
    user_num = int(input("insert your number:"))
    print(user_num)