print("{:=^20}".format("함수"))
print("{:-^20}".format("함수"))


def add(a, b):
    return a + b


print(add(1, 2))
print(add("A", "B")[0])
print(add([1, 2], [3, 4])[1])

print("-" * 20)
def odd_even(num):
    if num % 2 == 0:
        return "짝수"
    else:
        return "홀수"

print(odd_even(20))

# Practice 1
print("-" * 20)
def average(a, b):
    return (a + b) / 2

print(average(1, 2))

print("-" * 20)
def lst_average(lst):
    total = 0
    total_cnt = 0

    for num in lst:
        total += num
        total_cnt += 1
    return total / total_cnt

def lst_average(lst):
    return sum(lst) / len(lst)

print(lst_average([1, 3, 4, 6]))

print("-" * 20)
def say_my_name():
    return "영희"

say_my_name()

def print_my_name(name):
    print(name)

print_my_name("철수")

def say_hi():
    print("hi")

print(say_hi())

# Practice 2
print("-" * 20)
def return_my_name():
    return "sangmook"


def repeat_my_name(n):
    for _ in range(n):
        print("sangmook")


repeat_my_name(10)

print("-" * 20)
print("12", 10, 20, [1, 2, 3], 20)

print("-" * 20)
def my_sum(*args):
    total = 0
    for x in args:
        total += x
    return total

print(my_sum(1, 2, 3, 4, 5, 6, 7))


def sample(a, b, *args):
    print("a", a)
    print("b", b)
    print("args", args)

sample(1, 2, 3, 4, 5)


# Practice 3
print("-" * 20)
def my_average(*args):
    total = 0
    total_cnt = 0

    for num in args:
        total += num
        total_cnt += 1
    return total / total_cnt

print(my_average(1, 2, 3, 4, 5, 6, 7, 8))

def my_concat(c, *args):
    return c.join(args)

print(my_concat("-", "abc", "def", "ghi"))


print("-" * 20)
def sum_sub(a, b):
    return a + b, a - b

print(sum_sub(10, 20))

def sum_sub(a, b):
    return a + b
    print("TEST")
    return a - b

print(sum_sub(10, 20))


def get_max_min(lst):
    if len(lst) < 2:
        return
    return max(lst), min(lst)

print(get_max_min([1, 2, 3, 4, 5]))
print(get_max_min([1]))

print("-" * 20)

def add(a, b=20):
    return a + b

print(add(10))
print(add(10, 50))

print("-" * 20)
n = 10
print("before make_one", id(n))

def make_one():
    global n
    n = 1
    print("in make_one", id(n))
    print("make_one:", n)

make_one()
print("outside:", n)






















