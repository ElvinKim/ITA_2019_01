# lecture 2
# problem 2-1
a = 20180102

year = int(a / 10000)
month = int((a % 10000) / 100)
day = a % 100

print("{:04d}, {:02d}, {:02d}".format(year, month, day))

# problem 2-2
# word = input("please insert your string:")
# word_len = len(word)
#
# print(word[0] + "_" * (word_len - 1))

# lecture 4
# problem 4-1-1
print("-" * 20)
for x in range(5):
    print("*" * (x + 1))

# problem 4-1-2
print("-" * 20)
for x in range(5):
    for _ in range(x + 1):
        print("*", end="")
    print("")

# problem 4-2-1
print("-" * 20)
for x in range(5):
    print("{:^9}".format("*" * (2 * x + 1)))

# problem 4-2-2
print("-" * 20)
for x in range(5):
    for _ in range(5 - (x + 1)):
        print(" ", end="")
    for _ in range(2 * x + 1):
        print("*", end="")
    print("")


# problem 4-3
print("-" * 20)
sample_str = "ABCABAAB"
c = "A"
index_lst = []

for idx, x in enumerate(sample_str):
    if x == c:
        index_lst.append(idx)

print(index_lst)  # [0, 3, 5, 6]

# problem 4-4
print("-" * 20)
from random import randint
random_num = randint(1, 100)
trial_cnt = 0

while True:
    input_num = int(input("input number(1~100):"))
    trial_cnt += 1

    if random_num == input_num:
        print("맞췄습니다.")
        break
    elif random_num > input_num:
        print("높습니다.")
    else:
        print("낮습니다.")
print("시도 횟수:", trial_cnt)





















