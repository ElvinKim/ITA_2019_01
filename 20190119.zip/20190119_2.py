class Student:
    grade = 4
    gpa = 4.12
    name = "영희"
    student_id = "20181234"

    def study(self, subject, hour):
        print(subject + "를(을) " + str(hour) + "시간 공부합니다.")

    def eat(self, menu):
        print(self.name + "은(는)" + menu + "를(을)먹습니다.")


class Knight:
    level = 20
    name = "만년동 핵폭탄"
    hp = 200

    def move(self, direction):
        print(direction + "으로(로) 이동합니다.")

    def attack(self):
        print("self id", id(self))
        print(self.name + "이(가) 공격합니다.")


k1 = Knight()
print(k1.name)
k1.move("왼쪽")

print("k1", id(k1))
k1.attack()

print("-" * 20)

k2 = Knight()
print("k2", id(k2))
k2.attack()

















